using System;
using System.ComponentModel.DataAnnotations;

namespace ProjetSIO.Models
{
    public class ReserveEau
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string? Nom { get; set; }

        [Required]
        public double VolumeEau { get; set; } // En litres

        [Required]
        [MaxLength(10)]
        public string? CodePostal { get; set; }
    }
}
